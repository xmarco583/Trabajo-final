namespace Administrador
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Persona> personaList = new List<Persona>();
        private void button1_Click(object sender, EventArgs e)
        {
            personaList.Add(new Persona { Dni = txtDni.Text,Name = txtNombre.Text, Edad= txtEdad.Text, Adress =txtAdress.Text, Genero=cboGen.Text, Plan =cboPlan.Text, Trainer= cboTrainer.Text });
            mostrar();
            

        }
        public void mostrar()
        {
            txtLista.Clear();
            foreach(var p in personaList)
            {
                txtLista.Text += p.Dni + "  -  " + p.Name + "  -  " + p.Edad + "  -  " + p.Adress + "  -  " + p.Genero + "  -  " + p.Plan + "  -  " + p.Trainer + "\r\n";
            }
        }
       

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hay " + personaList.Count + " clientes");
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
                string tipo = "";

                for (int i = 0; i < personaList.Count; i++)
                {

                    if (personaList[i].Dni == txtMiembro.Text)
                    {
                        tipo = personaList[i].Plan;
                        MessageBox.Show("Su tipo de suscripci�n es " + tipo);
                        if (tipo == "Mensual (S/. 87.00)") { MessageBox.Show("Incluye evaluaci�n de composici�n corporal y programa de entrenamiento personalizado. " + " Su suscripci�n acaba en 20/07/2022"); }
                        if (tipo == "Trimestral (S/. 462.00)") { MessageBox.Show("Incluye un descuento del 25% si desea incluir otro mes a su plan de membres�a. " + " Su suscripci�n acaba en 20/09/2022"); }
                        if (tipo == "Anual (S/. 1169.00)") { MessageBox.Show("Descuento del 15% si desea contratar un plan igual a este acabada la membres�a. " + "Su inscripci�n acaba en 20/06/2023"); }

                    }

                   

                }
            
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Formtrainer formtra = new Formtrainer(personaList); 
            Formmiembro miembro = new Formmiembro(personaList);
            formtra.ShowDialog();
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Formmiembro miembro = new Formmiembro(personaList);
            miembro.ShowDialog();
        }
    }
}