﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administrador
{
    public class Trainer
    {
       
        public string rutina1 { get; set; }
        public string rutina2 { get; set; }
        public string maquina { get; set; }
        public int cp = 4, ce = 4, cb = 4, ct = 4, ch = 4, cpi = 4;
        public void veralumnostrainer(List<Persona> personaList,ComboBox cbo,TextBox text)
        {
            for (int i = 0; i < personaList.Count; i++)
            {

                if (personaList[i].Trainer == cbo.Text&&personaList[i].rutina==null&&personaList[i].maquina==null)
                {
                    text.Text += personaList[i].Dni + "  -  " + personaList[i].Name + "  -  " + personaList[i].Edad + "  -  " + personaList[i].Plan +"  -  Sin rutina"+"  -  Sin máquina" + "\r\n";


                }
                if(personaList[i].Trainer == cbo.Text && personaList[i].rutina != null && personaList[i].maquina != null)
                {
                    text.Text += personaList[i].Dni + "  -  " + personaList[i].Name + "  -  " + personaList[i].Edad + "  -  " + personaList[i].Plan + "  -  "+personaList[i].rutina+ "  -  " + personaList[i].maquina+"\r\n";
                }

            }
        }
        
        public void listademaquinas(ListBox lista)
        {
            lista.Items.Clear();
            lista.Items.Add("Máquina para pecho:" + cp + "\r\n");
            lista.Items.Add("Máquina para espalda:" + ce + "\r\n");
            lista.Items.Add("Máquina para biceps:" + cb + "\r\n");
            lista.Items.Add("Máquina para triceps:" + ct + "\r\n");
            lista.Items.Add("Máquina para hombro:" + ch + "\r\n");
            lista.Items.Add("Máquina para pierna:" + cpi + "\r\n");
        }
       
    }
}
