﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Administrador
{
    public partial class Formtrainer : Form
    {
        List<Persona> personaList = new List<Persona>();
        Queue<Trainer> rutina=new Queue<Trainer>();
        Trainer train=new Trainer();
        List<string> maquinas = new List<string> {""};
        public Formtrainer(List<Persona> listpersona)
        {
            InitializeComponent();
            personaList=listpersona;
        }

      int cp = 4, ce = 4, cb = 4, ct = 4, ch = 4, cpi = 4;

        private void btnselectra_Click(object sender, EventArgs e)
        {
            txtalumselec.Clear();
           
            train.veralumnostrainer(personaList,cboTrainerselec,txtalumselec);

        }
        public void asignarrutina()
        {
            txtalumselec.Clear();
            if (cp > 0 || ce > 0 || cb > 0 || ct > 0)
            {
                for (int i = 0; i < personaList.Count; i++)
                {

                    if (personaList[i].Dni == txtcodrutina.Text)
                    {
                        personaList[i].rutina = cboasignarrutina.Text;
                        personaList[i].maquina = cbomaquina.Text;

                        if (personaList[i].Trainer == cboTrainerselec.Text)
                        {

                            if (personaList[i].maquina == "Pecho") { cp--; }
                            if (personaList[i].maquina == "Espalda") { ce--; }
                            if (personaList[i].maquina == "Biceps") { cb--; }
                            if (personaList[i].maquina == "Triceps") { ct--; }
                            if (personaList[i].maquina == "Hombro") { ch--; }
                            if (personaList[i].maquina == "Pierna") { cpi--; }

                        }

                    }

                }
            }
            if (cp <= 0 || ce <= 0 || cb <= 0 || ct <= 0)
            {
                MessageBox.Show("MÁQUINAS NO DISPONIBLES");
            }
            listademaquinas();
            train.veralumnostrainer(personaList, cboTrainerselec, txtalumselec);

        }
        private void btnasigrutin_Click(object sender, EventArgs e)
        {
           asignarrutina();

        }

        private void button1_Click(object sender, EventArgs e)
        {   
            rutina.Enqueue(new Trainer { rutina1 = cborutina1.Text, rutina2 = cborutina2.Text });

                cboasignarrutina.Items.Clear();
                foreach (var p in rutina)
                {
               
                cboasignarrutina.Items.Add(p.rutina1 + " + " + p.rutina2);
                
                
                }
            txtcodrutina.Focus(); 
        }
        public void listademaquinas()
        {
            lstmaquinas.Items.Clear();
            lstmaquinas.Items.Add("Máquina para pecho:" + cp + "\r\n");
            lstmaquinas.Items.Add("Máquina para espalda:" + ce + "\r\n");
            lstmaquinas.Items.Add("Máquina para biceps:" + cb + "\r\n");
            lstmaquinas.Items.Add("Máquina para triceps:" + ct + "\r\n");
            lstmaquinas.Items.Add("Máquina para hombro:" + ch + "\r\n");
            lstmaquinas.Items.Add("Máquina para pierna:" + cpi + "\r\n");
        }
        private void Formtrainer_Load(object sender, EventArgs e)
        {
            listademaquinas();

        }
    }
}
