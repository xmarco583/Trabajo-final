﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administrador
{
    public class Persona
    {
        public string Dni { get; set; }
        public string Name { get; set; }
        public string Edad { get; set; }
        public string Adress { get; set; }
        public string Genero { get; set; }
        public string Plan { get; set; }
        public string Trainer { get; set; }
        public string rutina { get; set; }
        public string maquina { get; set; }

    }
}
